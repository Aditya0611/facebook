﻿# Logs Directory

This directory will contain structured JSON logs.

Log files:
- scraper.log (Facebook scraper logs)

Files are created automatically when you run the scraper.

﻿# Data Directory

This directory will contain scraped results.

Output files:
- facebook_top10_{category}_{timestamp}.json

Files are created automatically when you run the scraper.

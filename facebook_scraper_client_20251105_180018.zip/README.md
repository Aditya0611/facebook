# Facebook Trend Scraper

Production-ready Facebook scraper using Playwright with advanced analytics.

## ✅ All Issues Fixed

- ✅ **Dependencies in requirements.txt** - No in-process pip installs, fail-fast on import errors
- ✅ **Unified base.py** - Single canonical base class, no duplicates
- ✅ **Externalized config** - Categories in `config/categories.json`
- ✅ **JSON logging** - Structured logs, no print statements
- ✅ **Retry decorators** - Exponential backoff for page loads & Supabase writes
- ✅ **Enhanced analytics** - Time-weighted, sentiment-weighted, engagement normalization
- ✅ **Lifecycle tracking** - version_id, first_seen, last_seen timestamps
- ✅ **Unified schema** - TrendRecord for consistent data structure

## 🚀 Quick Start

### 1. Install
```bash
pip install -r requirements.txt
playwright install firefox
python -m textblob.download_corpora
```

### 2. Configure
Create `.env` file:
```env
FACEBOOK_EMAIL=your_email@example.com
FACEBOOK_PASSWORD=your_password

# Optional: Supabase for database storage
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_ANON_KEY=your_key
```

### 3. Run
```bash
# Interactive demo
python demo.py
```

## 📁 Project Structure

```
├── base.py                  # Facebook scraper (1,394 lines)
├── demo.py                  # Interactive demo
├── config/
│   └── categories.json     # 8 categories configuration
├── requirements.txt         # All dependencies
└── README.md               # This file
```

## 🎯 Features

### Categories
Technology | Business | Health | Food | Travel | Fashion | Entertainment | Sports

### Analytics
- **Engagement Score** (1-10): Weighted by likes, comments, shares
- **Trending Score** (0-100): Multi-factor algorithm
  - 22% Engagement (normalized)
  - 18% Post count (logarithmic)
  - 12% Total engagement (logarithmic)
  - 12% Average engagement (logarithmic)
  - 8% Sentiment (polarity)
  - 20% Time decay (exponential, 12-hour half-life)
  - 4% Consistency (coefficient of variation)
  - 4% Velocity (growth rate)
- **Sentiment Analysis**: Positive/Neutral/Negative with TextBlob
- **Time Weighting**: Exponential decay favoring recent trends

### Output
- **JSON files**: `data/facebook_top10_{category}_{timestamp}.json`
- **Supabase**: Automatic upload to database (optional)
- **Logs**: Structured JSON in `logs/scraper.log`

## 💻 Usage

### Interactive Demo
```bash
python demo.py
```

### Programmatic Usage
```python
from base import FacebookScraper
import uuid

with FacebookScraper(headless=True, debug=False) as scraper:
    if scraper.login():
        results = scraper.get_top_10_trending('technology', max_posts=30)
        scraper.save_results(results, 'technology', str(uuid.uuid4()))
```

### Example Output
```json
[
  {
    "platform": "Facebook",
    "topic_hashtag": "AI",
    "engagement_score": 8.5,
    "trending_score": 92.3,
    "sentiment_polarity": 0.65,
    "sentiment_label": "positive",
    "post_count": 45,
    "total_engagement": 125000,
    "avg_engagement": 2777.8,
    "likes": 85000,
    "comments": 30000,
    "shares": 10000,
    "category": "technology",
    "version_id": "abc-123-def-456",
    "scraped_at": "2025-10-22T14:30:00"
  }
]
```

## 🔧 Technical Implementation

### Architecture
```
base.py (1,394 lines)
├── Platform enum
├── TrendRecord dataclass (unified schema)
├── Retry decorators (page loads, Supabase writes)
├── BaseScraper (browser, logging, utilities)
└── FacebookScraper (platform-specific implementation)
```

### Data Model
```python
@dataclass
class TrendRecord:
    platform: str
    topic_hashtag: str
    engagement_score: float
    trending_score: float
    sentiment_polarity: float
    sentiment_label: str
    post_count: int
    total_engagement: int
    avg_engagement: float
    likes: int
    comments: int
    shares: int
    views: int
    category: str
    version_id: str
    first_seen: datetime
    last_seen: datetime
    scraped_at: datetime
    is_estimated: bool
    confidence_score: float
```

## 🛠️ Troubleshooting

### Login Issues
- Disable 2FA temporarily
- Run with `headless=False, debug=True` to see browser
- Check credentials in `.env` file

### No Results
- Verify category exists in `config/categories.json`
- Increase `max_posts` parameter
- Check `logs/scraper.log` for errors

### Dependencies
```bash
pip install -r requirements.txt --upgrade
playwright install firefox
python -m textblob.download_corpora
```

## 📊 Requirements

- Python 3.8+
- Firefox browser (via Playwright)
- 2GB RAM minimum
- Internet connection

## 🔒 Security

- Never commit `.env` file (in `.gitignore`)
- Use environment variables for credentials
- Keep dependencies updated
- Review logs regularly

---

**Ready to use!** Run `python demo.py` to start scraping Facebook trends.
